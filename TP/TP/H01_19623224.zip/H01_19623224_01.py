# NIM/Nama : 19623224/Muhammad Aditya Rahmadeni
# Tanggal  : 12 September 2023
# Deskripsi: Program Menentukan Kelulusan Berdasarkan Nilai 

# Kamus
# nilai_1 = integer
# nilai_2 = integer
# nilai_3 = integer
# nilai_4 = integer
# rata_rata = float
# status  = string

# Algoritma
# input
nilai_1 = int(input("Masukkan nilai ujian 1: "))
nilai_2 = int(input("Masukkan nilai ujian 2: "))
nilai_3 = int(input("Masukkan nilai ujian 3: "))
nilai_4 = int(input("Masukkan nilai ujian 4: "))
# proses
rata_rata = (nilai_1 + nilai_2 + nilai_3 + nilai_4) / 4
status = ''
if nilai_1 >= 50 and nilai_2 >= 50 and nilai_3 >= 50 and nilai_4 >= 50 and rata_rata >= 70:
    status = 'lulus'
else: # salahs satu nilai < 50 atau rata rata < 70 
    status = 'tidak lulus'
print(f'Tuan Kil {status} kelas Tuan Leo.')