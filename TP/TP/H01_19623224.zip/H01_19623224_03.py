# NIM/Nama : 19623224/Muhammad Aditya Rahmadeni
# Tanggal  : 12 September 2023
# Deskripsi: Program Menentukan Kelas dan Harga Kursi

# Kamus
# nomor = integer
# posisi = string
# kelas = string
# harga = integer

# Algoritma
# input
nomor = int(input("Tentukan Nomor Kursi : "))
posisi = input("Tentukan Posisi Kursi : ")
# Proses
kelas = ''
harga = 0
if nomor in range(1, 21) or nomor in range(51,61):
    kelas = 'hot seat'
    if posisi == 'A' or posisi == 'F':
        harga = 1_600_000
    elif posisi == 'B' or posisi == 'E':
        harga = 1_550_000
    else: # Posisi == 'C' atau 'D'
        harga = 1_500_000
else: #nomor in range(21, 51) or nomor in range(61,101):
    kelas = 'Regular'
    if posisi == 'A' or posisi == 'F':
        harga = 1_000_000
    elif posisi == 'B' or posisi == 'E':
        harga = 950_000
    else: # Posisi == 'C' atau 'D'
        harga = 900_000

print(f'Tuan Kil memilih kursi {kelas} dengan harga {harga}.')