# NIM/Nama : 19623224/Muhammad Aditya Rahmadeni
# Tanggal  : 12 September 2023
# Deskripsi: Program Menentukan Kemiringan Garis 

# Kamus
# x1 = float
# y1 = float
# x2 = float
# y2 = float

# Algoritma
# input
x1 = float(input('Masukkkan x1: '))
y1 = float(input('Masukkkan y1: '))
x2 = float(input('Masukkkan x2: '))
y2 = float(input('Masukkkan y2: '))
# proses
if x1 == x2:
    print('Garis tersebut merupakan garis vertikal.')
elif y1 == y2:
    print('Garis tersebut merupakan garis horizontal.')
else: # x1 != x2 and y1 != y2
    print(f'Garis tersebut memiliki gradien {( y2 - y1 )/(x2 - x1)}.')
